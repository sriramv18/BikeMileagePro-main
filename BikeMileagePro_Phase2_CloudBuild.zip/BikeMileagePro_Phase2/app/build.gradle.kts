plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sriram.bikemileagepro"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sriram.bikemileagepro"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
